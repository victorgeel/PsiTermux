# freenet

>Copyright By Ro0TN3T
>
>Satu Niat - Satu Semangat - Satu Komando

# Cara Gunakan

>$ apt update
>
>$ apt upgrade
>
>$ pkg install python
>
>$ pkg install python2
>
>$ pip2 install requests
>
>$ pip2 install mechanize
>
>$ pkg install git
>
>$ gir clone https://github.com/Ro0TP00R777Channel/freenet



# >Cara M3nj4l4nk4n<



>$ cd freenet
>
>$ chmod +x Main.py
>
>$ python2 Main.py

# Bahan

>1.Termux
>
>2.Psiphon pro
>
>Kalian Bebas Gunakan psiphon pro MOD 
 >
 >Atau psiphon vpn di play store

![hogo](https://i.postimg.cc/VLTDPM1y/Screenshot-2019-10-27-16-23-03-196-com-psiphon3-subscription-pic.png)

![hogo](https://i.postimg.cc/Kc35rjBJ/Screenshot-2019-10-27-16-23-09-585-com-psiphon3-subscription-pic.png)

![hogo](https://i.postimg.cc/QxBbXbX8/Screenshot-2019-10-27-16-48-47-787-com-termux.png)

# Kalian buka psiphon pro

![hogo](https://i.postimg.cc/CxckknMP/Screenshot-2019-10-27-16-55-43-138-com-psiphon3-subscription-pic.png)

Kalian Kik Start

# Tanda Kalo Berhasil Atau Tidak/Gagal

![hogo](https://i.postimg.cc/mZ3c718Y/Screenshot-2019-10-27-16-50-07-601-com-miui-gallery-picsay.png)
